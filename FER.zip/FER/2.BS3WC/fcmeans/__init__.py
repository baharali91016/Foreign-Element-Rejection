"""fuzzy-c-means - A simple implementation of Fuzzy C-means algorithm."""
from .fcm import FCM
